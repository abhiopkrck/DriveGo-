import "./CarCard.css";
import { FaHeart, FaGasPump, FaUsers, FaCog } from "react-icons/fa";
import { Link } from "react-router-dom";

function CarCard({ car }) {
  return (
    <Link to={`/cars/${car.id}`} className="car-link">
      <div className="car-card">

        <div className="car-image">
          <img src={car.image} alt={car.name} />

          <button className="wishlist">
            <FaHeart />
          </button>
        </div>

        <div className="car-info">

          <h3>{car.name}</h3>

          <p className="price">
            ₹{car.price} <span>/ Day</span>
          </p>

          <div className="car-features">

            <span>
              <FaGasPump />
              {car.fuel}
            </span>

            <span>
              <FaCog />
              {car.transmission}
            </span>

            <span>
              <FaUsers />
              {car.seats} Seats
            </span>

          </div>

          <button className="book-btn">
            Book Now
          </button>

        </div>

      </div>
    </Link>
  );
}

export default CarCard;