import "./FeaturedCars.css";
import { useState } from "react";
import CarCard from "../CarCard/CarCard";
import cars from "../../data/cars";

function FeaturedCars() {

  const [category, setCategory] = useState("All");

  const filteredCars =
    category === "All"
      ? cars
      : cars.filter((car) => car.category === category);

  return (
    <section className="featured">

      <div className="container">

        <div className="section-title">
          <p>Our Collection</p>
          <h2>Featured Cars</h2>
        </div>

        <div className="category-buttons">

          <button onClick={() => setCategory("All")}>All</button>

          <button onClick={() => setCategory("SUV")}>SUV</button>

          <button onClick={() => setCategory("Sedan")}>Sedan</button>

          <button onClick={() => setCategory("Luxury")}>Luxury</button>

          <button onClick={() => setCategory("Sports")}>Sports</button>

          <button onClick={() => setCategory("Supercar")}>Supercars</button>

        </div>

        <div className="car-grid">

          {filteredCars.map((car) => (
            <CarCard
              key={car.id}
              car={car}
            />
          ))}

        </div>

      </div>

    </section>
  );
}

export default FeaturedCars;