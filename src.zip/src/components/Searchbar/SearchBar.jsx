import "./SearchBar.css";
import {
  FaLocationDot,
  FaCalendarDays,
  FaCarSide,
} from "react-icons/fa6";

function SearchBar() {
  return (
    <section className="search-section">
      <div className="container">

        <div className="search-box">

          {/* Pickup Location */}
          <div className="search-item">
            <label>
              <FaLocationDot className="icon" />
              Pickup Location
            </label>

            <select>
              <option>Select Location</option>
              <option>Pune</option>
              <option>Mumbai</option>
              <option>Delhi</option>
              <option>Bangalore</option>
              <option>Hyderabad</option>
            </select>
          </div>

          {/* Pickup Date */}
          <div className="search-item">
            <label>
              <FaCalendarDays className="icon" />
              Pickup Date
            </label>

            <input type="date" />
          </div>

          {/* Return Date */}
          <div className="search-item">
            <label>
              <FaCalendarDays className="icon" />
              Return Date
            </label>

            <input type="date" />
          </div>

          {/* Car Category */}
          <div className="search-item">
            <label>
              <FaCarSide className="icon" />
              Car Category
            </label>

            <select>
              <option>All Cars</option>
              <option>Hatchback</option>
              <option>Sedan</option>
              <option>SUV</option>
              <option>Luxury</option>
              <option>Sports</option>
              <option>Supercar</option>
            </select>
          </div>

          {/* Search Button */}
          <button className="search-btn">
            Search Cars
          </button>

        </div>

      </div>
    </section>
  );
}

export default SearchBar;