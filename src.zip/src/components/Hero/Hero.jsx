import "./Hero.css";

function Hero() {
  return (
    <section className="hero">

      <div className="container hero-content">

        <div className="hero-left">

          <p className="hero-tag">
            🚗 India's Premium Car Rental
          </p>

          <h1>
            Find Your <span>Dream Car</span>
          </h1>

          <p className="hero-description">
            Rent hatchbacks, SUVs, luxury cars and supercars at the best
            prices. Book instantly with exclusive daily and monthly offers.
          </p>

          <button className="hero-btn">
            Explore Cars
          </button>

        </div>

        <div className="hero-right">

          {/* We'll add a car PNG here later */}

        </div>

      </div>

    </section>
  );
}

export default Hero;