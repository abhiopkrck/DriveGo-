import "./Navbar.css";
import { NavLink } from "react-router-dom";
import { FaBars, FaTimes, FaSearch } from "react-icons/fa";
import { useState } from "react";

function Navbar() {
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <header className="navbar">
      <div className="container nav-container">

        {/* Logo */}
        <div className="logo">
          🚗 DriveGo
        </div>

        {/* Navigation */}
        <nav className={menuOpen ? "nav-menu active" : "nav-menu"}>

          <NavLink to="/" onClick={() => setMenuOpen(false)}>
            Home
          </NavLink>

          <NavLink to="/cars" onClick={() => setMenuOpen(false)}>
            Cars
          </NavLink>

          <NavLink to="/deals" onClick={() => setMenuOpen(false)}>
            Deals
          </NavLink>

          <NavLink to="/about" onClick={() => setMenuOpen(false)}>
            About
          </NavLink>

          <NavLink to="/contact" onClick={() => setMenuOpen(false)}>
            Contact
          </NavLink>

        </nav>

        {/* Right Side */}
        <div className="nav-right">

          <FaSearch className="search-icon" />

          <NavLink to="/login" className="login-btn">
            Login
          </NavLink>

          <NavLink to="/signup" className="signup-btn">
            Signup
          </NavLink>

          <button
            className="menu-btn"
            onClick={() => setMenuOpen(!menuOpen)}
          >
            {menuOpen ? <FaTimes /> : <FaBars />}
          </button>

        </div>

      </div>
    </header>
  );
}

export default Navbar;