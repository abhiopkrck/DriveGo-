import "./Booking.css";
import { useParams } from "react-router-dom";
import { useState } from "react";
import cars from "../data/cars";

function Booking() {

    const { id } = useParams();

    const car = cars.find(
        (c) => c.id === Number(id)
    );

    const [pickupDate, setPickupDate] = useState("");
    const [returnDate, setReturnDate] = useState("");
    const [location, setLocation] = useState("Pune");
    const [driver, setDriver] = useState("No");

    const calculateDays = () => {

        if (!pickupDate || !returnDate)
            return 0;

        const start = new Date(pickupDate);
        const end = new Date(returnDate);

        const diff = end - start;

        return Math.max(
            Math.ceil(diff / (1000 * 60 * 60 * 24)),
            0
        );
    };

    const days = calculateDays();

    const total =
        days * car.price +
        (driver === "Yes" ? days * 1000 : 0);

    return (

        <section className="booking-page">

            <div className="container booking-container">

                <div className="booking-left">

                    <img
                        src={car.image}
                        alt={car.name}
                    />

                </div>

                <div className="booking-right">

                    <h1>{car.name}</h1>

                    <h2>₹ {car.price} / Day</h2>

                    <form>

                        <label>Pickup Date</label>

                        <input
                            type="date"
                            value={pickupDate}
                            onChange={(e) =>
                                setPickupDate(e.target.value)
                            }
                        />

                        <label>Return Date</label>

                        <input
                            type="date"
                            value={returnDate}
                            onChange={(e) =>
                                setReturnDate(e.target.value)
                            }
                        />

                        <label>Pickup Location</label>

                        <select
                            value={location}
                            onChange={(e) =>
                                setLocation(e.target.value)
                            }
                        >

                            <option>Pune</option>
                            <option>Mumbai</option>
                            <option>Delhi</option>
                            <option>Bangalore</option>

                        </select>

                        <label>Driver Required?</label>

                        <select
                            value={driver}
                            onChange={(e) =>
                                setDriver(e.target.value)
                            }
                        >

                            <option>No</option>
                            <option>Yes</option>

                        </select>

                        <div className="booking-summary">

                            <h3>Booking Summary</h3>

                            <p>
                                Days :
                                <span>{days}</span>
                            </p>

                            <p>
                                Driver :
                                <span>{driver}</span>
                            </p>

                            <p className="total">

                                Total :

                                <span>

                                    ₹ {total}

                                </span>

                            </p>

                        </div>

                        <button>

                            Confirm Booking

                        </button>

                    </form>

                </div>

            </div>

        </section>

    );
}

export default Booking;