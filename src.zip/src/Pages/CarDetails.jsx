import { useParams } from "react-router-dom";
import cars from "../data/cars";

function CarDetails() {
  const { id } = useParams();

  const car = cars.find((c) => c.id === Number(id));

  if (!car) {
    return <h2 style={{ textAlign: "center" }}>Car Not Found</h2>;
  }

  return (
    <div className="container" style={{ padding: "50px 0" }}>
      <div className="details">

        <img
          src={car.image}
          alt={car.name}
          width="500"
        />

        <div>

          <h1>{car.name}</h1>

          <h2>₹ {car.price} / Day</h2>

          <p>Fuel : {car.fuel}</p>

          <p>Transmission : {car.transmission}</p>

          <p>Seats : {car.seats}</p>

          <button>
            Book Now
          </button>

        </div>

      </div>
    </div>
  );
}

export default CarDetails;