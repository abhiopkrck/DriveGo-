import Navbar from '../components/Navbar/Navbar';

function Contacts(){
    return(
    <Navbar/>
    )
}
export default Contacts ;