import Navbar from '../components/Navbar/Navbar';

function Deals(){
    return(
        <Navbar/>
    )
}
export default Deals ;