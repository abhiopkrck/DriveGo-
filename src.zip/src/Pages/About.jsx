import Navbar from '../components/Navbar/Navbar';


function About(){
    return(
         <>
    <Navbar/>
    </>
    )
}
export default About;