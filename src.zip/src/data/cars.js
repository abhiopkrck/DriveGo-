const cars = [
  {
    id: 1,
    name: "Lamborghini Huracan",
    price: 25000,
    category: "Supercar",
    fuel: "Petrol",
    transmission: "Auto",
    seats: 2,
    image: "/cars/lamborghini.png",
  },

  {
    id: 2,
    name: "Ferrari 488",
    price: 28000,
    category: "Supercar",
    fuel: "Petrol",
    transmission: "Auto",
    seats: 2,
    image: "/cars/ferrari.png",
  },

  {
    id: 3,
    name: "Mahindra Thar",
    price: 4500,
    category: "SUV",
    fuel: "Diesel",
    transmission: "Manual",
    seats: 4,
    image: "/cars/thar.png",
  },

  {
    id: 4,
    name: "Honda City",
    price: 3000,
    category: "Sedan",
    fuel: "Petrol",
    transmission: "Manual",
    seats: 5,
    image: "/cars/city.png",
  },
];

export default cars;