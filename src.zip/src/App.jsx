import "./App.css";
import { Routes, Route } from "react-router-dom";

import Home from "./Pages/Home";
import About from "./Pages/About";
import Login from "./Pages/Login";
import Signup from "./Pages/Signup";
import Profile from "./Pages/Profile";
import Deals from "./Pages/Deals";
import Contact from "./Pages/Contact";
import Cars from "./Pages/Cars";
import Booking from "./Pages/Booking";
import CarDetails from "./Pages/CarDetails";

function App() {
  return (
    <Routes>
      <Route path="/" element={<Home />} />

      <Route path="/login" element={<Login />} />
      <Route path="/signup" element={<Signup />} />
      <Route path="/profile" element={<Profile />} />

      <Route path="/cars" element={<Cars />} />
      <Route path="/cars/:id" element={<CarDetails />} />

      <Route path="/booking/:id" element={<Booking />} />

      <Route path="/about" element={<About />} />
      <Route path="/deals" element={<Deals />} />
      <Route path="/contact" element={<Contact />} />
    </Routes>
  );
}

export default App;